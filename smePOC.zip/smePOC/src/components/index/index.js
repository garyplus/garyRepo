import React, { Component } from "react";
import "./index.css";
import {  Redirect} from 'react-router-dom';



class Index extends Component {
  render() {
    return (
      <div>
        <Redirect 
                to={
                    {
                        pathname:"/logon"
                    }
                } 
            >POC</Redirect>
        {this.props.children}

      </div>
    );
  }
}

export default Index;
