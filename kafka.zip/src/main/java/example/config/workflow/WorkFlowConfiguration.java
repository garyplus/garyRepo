package example.config.workflow;

import example.entity.worker.PocEntity;
import example.worker.demo.listener.*;
import example.worker.demo.worker.reader.CustomNamePocReader;
import example.worker.demo.worker.tasklet.TaskletAppendBlock;
import example.worker.demo.worker.writer.CustNamePocWriter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.support.CompositeItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Configuration
@EnableBatchProcessing
@Slf4j
public class WorkFlowConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Resource
	private JobListener jobListener;

	@Autowired
	private ItemProcessor<PocEntity, PocEntity> CustNameProcessor;
	
	@Bean
	@StepScope
	public CustomNamePocReader reader() {
		return  new CustomNamePocReader();
	}

	@Bean
	public CustNamePocWriter writer() {
		return new CustNamePocWriter();
	}

	@Bean
	public CompositeItemProcessor<PocEntity, PocEntity> getDataProcessor() {
		CompositeItemProcessor<PocEntity, PocEntity> processor = new CompositeItemProcessor<>();
		List<ItemProcessor<PocEntity, PocEntity>> list = new ArrayList<>();
		list.add(CustNameProcessor);
		processor.setDelegates(list);
		return processor;
	}


	@Bean
	public Step garyPocJobStep1() {
		return stepBuilderFactory.get("garyPocJobStep1").
				<PocEntity, PocEntity>chunk(10).
				listener(new ChunkListener())
				.reader(reader()).listener(new ReaderListener())
				.processor(getDataProcessor()).listener(new ProcessorListener())
				.writer(writer()).listener(new WriterListener()).
						faultTolerant().backOffPolicy(new ExponentialBackOffPolicy()).
						     skipLimit(1).skip(Exception.class).//allow skip time , and specify Exception case
						     retryLimit(3).retry(Exception.class)//allow retry time , and specify Exception case , like connect time out and so on
				.build();
	}


	@Bean
	public Job garyPocJob() {
		return jobBuilderFactory.get("garyPocJob").incrementer(new RunIdIncrementer()).flow(garyPocJobStep1()).end().listener(jobListener).build();
	}


	@Bean
	public TaskletAppendBlock taskletDetail() {
		TaskletAppendBlock tasklet = new TaskletAppendBlock();
		String ipArr [] = "1,2,3,4,5,6,7,8".split(",");
		tasklet.setIpParams(ipArr);

		return tasklet;
	}

	@Bean
	public Step garyPocTaskletJobStep() {
		return this.stepBuilderFactory.get("garyPocTaskletJobStep1")
				.tasklet(taskletDetail())
				.build();
	}


	@Bean
	public Job garyPocTaskletJob() {
		return jobBuilderFactory.get("garyPocTaskletJob").start(garyPocTaskletJobStep()).build();
	}
}
