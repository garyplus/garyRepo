package example.controller;

import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;

import java.util.Arrays;
import java.util.Map;
import java.util.Properties;

public class Test {
    public static void main(String[] args) throws InterruptedException {

        Properties props = new Properties();
        props.put("bootstrap.servers", "127.0.0.1:9092");
        props.put("group.id", "test");
        props.put("enable.auto.commit", "true");
        props.put("auto.commit.interval.ms", "1000");
        props.put("session.timeout.ms", "15000");
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        //create consumer
        KafkaConsumer consumer = new KafkaConsumer<String,String>(props);
        System.out.println("=================================start get msg=========================================");
        consumer.subscribe(Arrays.asList("test"));
        boolean exitVar = false;
        while (!exitVar) {
            ConsumerRecords<String, String> records = consumer.poll(1000);
            for (ConsumerRecord<String, String> record : records) {
                System.out.println("====================================record.value();......" + record.value());
                consumer.commitAsync(new OffsetCommitCallback() {
                    @Override
                    public void onComplete(Map<TopicPartition, OffsetAndMetadata> offsets, Exception exception) {
                        if (exception != null) {
                            System.out.println("提交失败：" + offsets);
                        }
                    }
                });
                exitVar = true;
            }
            Thread.sleep(5000);
        }
        System.out.println("=================================end get msg=========================================");
    }
}
