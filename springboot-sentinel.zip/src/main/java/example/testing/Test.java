package example.testing;

import example.executor.VisiableThreadPoolTaskExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

@Slf4j
public class Test {

        public static void main(String[] args) {

            ThreadPoolTaskExecutor threadPoolTaskExecutor = new VisiableThreadPoolTaskExecutor(){
                @Override
                public <T> Future<T> submit(Callable<T> task) {
                    log.info("interceptor ");
                    return super.submit(task);
                }

            };
            //核心线程数
            threadPoolTaskExecutor.setCorePoolSize(5);
            threadPoolTaskExecutor.setAllowCoreThreadTimeOut(true);
            //最大线程数
            threadPoolTaskExecutor.setMaxPoolSize(8);
            //配置队列大小
            threadPoolTaskExecutor.setQueueCapacity(5);
            //配置线程池前缀
            threadPoolTaskExecutor.setThreadNamePrefix("async-service-");
            //拒绝策略
            threadPoolTaskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.AbortPolicy());
            threadPoolTaskExecutor.initialize();
            AtomicInteger counter = new AtomicInteger(0);

            IntStream.range(0, 15).forEach(
                    index -> threadPoolTaskExecutor.execute(() -> {
                try {
                    Thread.sleep(1000);
                    System.out.println("running: " + System.currentTimeMillis() + ": " + counter.incrementAndGet());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                   })
            );
        }
}
