package example.mapper;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PocMapper {

        String getAssessorInfo(@Param("assessor") String assessor);
}
