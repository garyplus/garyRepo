package example.service.impl;

import example.config.kafka.AbstractSendMessageListener;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class KafkaServiceImpl {

    @Autowired
    private KafkaTemplate kafkaTemplate;


    public void doSend(String topic,String msg) {

        kafkaTemplate.setProducerListener(new AbstractSendMessageListener(){
            @Override
            public void success(ProducerRecord producerRecord, RecordMetadata recordMetadata) {
                log.info("=================KafkaServiceImpl Success Report====================");
                log.info("topic is [{}]", producerRecord.topic());
                log.info("partition is [{}]", producerRecord.partition());
                log.info("key is [{}]", producerRecord.key());
                log.info("value is [{}]", producerRecord.value());
                log.info("recordMetadata is [{}]", recordMetadata);
                log.info("=================KafkaServiceImpl Success Report====================");
            }

            @Override
            public void failure(ProducerRecord producerRecord, Exception exception) {

                log.info("=================KafkaServiceImpl Fail Report====================");
                log.info("topic is [{}]", producerRecord.topic());
                log.info("partition is [{}]", producerRecord.partition());
                log.info("key is [{}]", producerRecord.key());
                log.info("value is [{}]", producerRecord.value());
                log.info("exception is [{}]  [{}]", producerRecord.value(), exception.getMessage());
                log.info("=================KafkaServiceImpl Success Report====================");
            }

        });
        kafkaTemplate.send(topic,1,System.currentTimeMillis(),"key",msg);

    }
}
