package example.worker.demo.worker.processor;

import example.entity.worker.PocEntity;
import example.service.impl.KafkaServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class CustNamePocProcessor implements ItemProcessor<PocEntity, PocEntity> {

    @Autowired
    private KafkaServiceImpl kafkaServiceImpl;

    @Override
    public PocEntity process(PocEntity testEitity) throws Exception {
        //if process no dependency , you can consider about async thread pool process , like send log to 3rd party ,etc.
        String userName = testEitity.getUserName();
        log.info("processor data : " + userName);
        kafkaServiceImpl.doSend("test",userName);

        return  testEitity;
    }
}
