package example.config.kafka;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.kafka.support.ProducerListener;

/*
suggest use for the message sender / producer

 */
@Slf4j
public abstract class AbstractSendMessageListener<K,V> implements ProducerListener<K,V> {

        public abstract void success(ProducerRecord<K, V> producerRecord,
                                     RecordMetadata recordMetadata);

        public abstract void failure(ProducerRecord<K, V> producerRecord, Exception exception);

        @Override public void onSuccess(ProducerRecord<K, V> producerRecord,
                                        RecordMetadata recordMetadata) {
            log.info("=================Success Report====================");
            log.info("topic is [{}]", producerRecord.topic());
            log.info("partition is [{}]", producerRecord.partition());
            log.info("key is [{}]", producerRecord.key());
            log.info("value is [{}]", producerRecord.value());
            log.info("recordMetadata is [{}]", recordMetadata);
            log.info("=================Success Report====================");
            this.success(producerRecord,recordMetadata);
        }

        @Override
        public void onError(ProducerRecord<K, V> producerRecord, Exception exception) {

            log.info("=================Fail Report====================");
            log.info("topic is [{}]", producerRecord.topic());
            log.info("partition is [{}]", producerRecord.partition());
            log.info("key is [{}]", producerRecord.key());
            log.info("value is [{}]", producerRecord.value());
            log.info("exception is [{}]  [{}]", producerRecord.value(), exception.getMessage());
            log.info("=================Success Report====================");
            this.failure(producerRecord,exception);
        }
}
