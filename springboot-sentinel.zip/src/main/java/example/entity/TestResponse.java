package example.entity;

import lombok.Data;

@Data
public class TestResponse {
    String result;
    String resultn;
}
