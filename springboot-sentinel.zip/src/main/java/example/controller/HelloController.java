package example.controller;

import example.entity.TestResponse;
import example.entity.UserBean;
import example.event.OrderEvent;
import example.event.UserRegisterEvent;
import example.service.AssessorService;
import example.service.ThreadPoolService;
import example.service.impl.EventServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.concurrent.Future;

@RestController
@Api(value = "desc of demo")
@Slf4j
public class HelloController {

    @Autowired
    AssessorService assessorService;

    @Autowired
    ThreadPoolService threadPoolService;

    @Autowired
    EventServiceImpl eventServiceImpl;

    @Autowired
    private ApplicationContext context;


    @ApiOperation(value = "desc of method", notes = "")
    @GetMapping(value = "/hi" , produces = "application/json")
    public TestResponse hello(@ApiParam(value = "No. of assessor" , required = true) @RequestParam String assessorNo) throws InterruptedException {
        log.info("accept parameter:{} ", assessorNo);
        TestResponse ts = new TestResponse();
        ts.setResult(assessorService.getAssessorInfo(assessorNo));
        ts.setResultn("");
        return ts;
    }

    @ApiOperation(value = "desc of sentinelIdx", notes = "")
    @GetMapping(value = "/sentinelIdx")
    public String sentinelIdx() {

        try {
            Future<String> future1 = threadPoolService.doTask1();
            Future<String> future2 = threadPoolService.doTask1();
            Future<String> future3 = threadPoolService.doTask1();
            Future<String> future4 = threadPoolService.doTask1();
            while (true) {
                if (future1.isDone() && future2.isDone() && future3.isDone() && future4.isDone()) {
                    log.info("Task1 result:{}", future1.get());
                    log.info("Task2 result:{}", future2.get());
                    log.info("Task2 result:{}", future3.get());
                    log.info("Task2 result:{}", future4.get());
                    break;
                }
                Thread.sleep(1000);
            }
            log.info("All tasks finished.");
            return "S";
        } catch (InterruptedException e) {
            log.error("错误信息1", e);
            return "F";
        } catch (Exception e) {
            log.error("错误信息2", e);
            return "FX";
        }
    }

    @GetMapping("/thread")
    public String testThread() {
        try {
            Future<String> future1 = threadPoolService.doTask1();
            Future<String> future2 = threadPoolService.doTask2();

        while (true) {
            if (future1.isDone() && future2.isDone()) {
                log.info("Task1 result:{}", future1.get());
                log.info("Task2 result:{}", future2.get());
                break;
            }
            Thread.sleep(1000);
        }
        log.info("All tasks finished.");
        return "S";
        } catch (InterruptedException e) {
        log.error("错误信息1", e);
        return "F";
        } catch (Exception e) {
        log.error("错误信息2", e);
        return "FX";
        }
    }


    @GetMapping("/thread2")
    public String testThread2() throws InterruptedException {

        eventServiceImpl.service1();
        return "s";
    }

    @GetMapping("/threadWriteLock")
    public String threadWriteLock() throws InterruptedException {
        try {
            Future<String> future1 = eventServiceImpl.service2();

            while (true) {
                if (future1.isDone()) {
                    log.info("Task1 result:{}", future1.get());
                    break;
                }
                Thread.sleep(1000);
            }
            log.info("All tasks finished.");
            return future1.get();
        } catch (InterruptedException e) {
            log.error("错误信息1", e);
            return "F";
        } catch (Exception e) {
            log.error("错误信息2", e);
            return "FX";
        }
    }

    @GetMapping("/threadReadLock")
    public String threadReadLock()  {
        try {
            Future<String> future1 = eventServiceImpl.service3();

            while (true) {
                if (future1.isDone()) {
                    log.info("Task1 result:{}", future1.get());
                    break;
                }
                Thread.sleep(1000);
            }
            log.info("All tasks finished.");
            return future1.get();
        } catch (InterruptedException e) {
            log.error("错误信息1", e);
            return "F";
        } catch (Exception e) {
            log.error("错误信息2", e);
            return "FX";
        }
    }

    @GetMapping("/threadReadLock2")
    public String threadReadLock2()  {
        return eventServiceImpl.getServiceCount();
    }

    @ApiOperation(value = "desc of testListener", notes = "")
    @GetMapping(value = "/testListener")
    public String testListener() {
//        context.publishEvent(OrderEvent.builder().msg("建立订单").build());


        UserBean ub = new UserBean();
        ub.setName("bbbb");
        ub.setPassword("11111");
        context.publishEvent(new UserRegisterEvent(this, ub));
        return "s";
    }

    @ApiOperation(value = "desc of testListener", notes = "")
    @GetMapping(value = "/testListener2")
    public String testListener2() {
        eventServiceImpl.publishUserBeanEvent();
        return "s";
    }
}
