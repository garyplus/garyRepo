var express = require('express')
var passport = require('passport');
var GoogleStrategy = require('passport-google-oauth').OAuth2Strategy;


const PORT = process.env.PORT || 8080;

// clientID = "399309520461-5kuvgeuah0hd4u428ers5v0knstj7327.apps.googleusercontent.com";
// clientSecret = "9AbuWq6p3G_0PYL_3Leg1tMw";
clientID = "399309520461-mjniqduca6nkabv9u5or89cbsvgfj0ph.apps.googleusercontent.com";
clientSecret = "k6CwrD7rgXLx71H-NyVjV3jJ";
callbackURL = "http://localhost:8080/auth/google/callback";

var garyStrategy = new GoogleStrategy({
  clientID: clientID,
  clientSecret: clientSecret,
  callbackURL: callbackURL
},
function(accessToken, refreshToken, profile, done) {
  console.log("accessToken...."+accessToken);
  console.log("refreshToken...."+refreshToken);
  if (profile) {
      user = profile;
      return done(null, user);
  } else {
      return done(null, false);
  }
}
)
var HttpsProxyAgent = require('https-proxy-agent');
var httpsProxyAgent = new HttpsProxyAgent("intpxy6.hk.hsbc:18084")
garyStrategy._oauth2.setAgent(httpsProxyAgent)
passport.use(garyStrategy);

passport.serializeUser(function(user, done) {
  done(null, user);
});

passport.deserializeUser(function(user, done) {
  done(null, user);
});

var app = express()
app.use(passport.initialize())
app.use(passport.session())

app.get('/auth/google',
  passport.authenticate('google', { scope: ['https://www.googleapis.com/auth/tagmanager.publish'],includeGrantedScopes :true,accessType:'offline' })
)

app.get('/auth/google/callback', 
  passport.authenticate('google'),
  function(req, res) {
	  res.status(200).send('Private Page')
});

app.listen(PORT, () => { console.log(`Listening on port ${PORT}`) })
