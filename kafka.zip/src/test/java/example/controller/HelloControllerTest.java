package example.controller;

import example.Application;
import example.service.impl.ThreadPoolServiceImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@WebAppConfiguration
public class HelloControllerTest {

    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;

    private MockMvc mockMvcFail;

    @InjectMocks
    private HelloController controller;

    @Mock
    private ThreadPoolServiceImpl threadPoolServiceImpl;

    @Before
    public void setUp() throws Exception{
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        mockMvcFail = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    public void testThread_success() throws Exception{
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/thread")
                .header("x-request-id", "123")
                .accept(MediaType.TEXT_HTML_VALUE))
                .andDo(MockMvcResultHandlers.print())
                .andReturn();
        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();

        Assert.assertEquals(HttpStatus.OK.value(), status);
        Assert.assertEquals("S", content);
    }

    //specify stub function
//    ThreadPoolService impl = mock(ThreadPoolService.class);
//    when(impl.doTask1()).thenThrow(new InterruptedException("sth go wrong."));
//        try {
//        impl.doTask1();
//    } catch (InterruptedException e) {
//    }
    @Test
    public void testThread_exception_Interrupted() throws Exception{

        Mockito.when(threadPoolServiceImpl.doTask1())
                .thenThrow(new InterruptedException("sth go wrong."));
        MvcResult mvcResult = mockMvcFail.perform(MockMvcRequestBuilders.get("/thread")
                .header("x-request-id", "123")
                .accept(MediaType.TEXT_HTML_VALUE))
                .andDo(MockMvcResultHandlers.print())
                .andReturn();
        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();

        Assert.assertEquals(HttpStatus.OK.value(), status);
        Assert.assertEquals("F", content);
    }

    @Test
    public void hello() throws Exception{

        /**
         * 1、mockMvc.perform execute one http request。
         * 2、MockMvcRequestBuilders.get'aaa' build a http request builder with 'aaa' uri。
         * 3、ResultActions.param add param
         * 4、ResultActions.accept(MediaType.TEXT_HTML_VALUE) set type of result body
         * 5、ResultActions.andExpect add the assert for result。
         * 6、ResultActions.andDo
         *   MockMvcResultHandlers.print() print response msg。
         * 5、ResultActions.andReturn execute completed and return the result 。
         */

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/hi")
                .param("assessorNo", "HA007")
                .accept(MediaType.TEXT_HTML_VALUE))
                // .andExpect(MockMvcResultMatchers.status().isOk())             //equals to Assert.assertEquals(200,status);
                // .andExpect(MockMvcResultMatchers.content().string("hello Gary"))    //equals to Assert.assertEquals("hello Gary",content);
                .andDo(MockMvcResultHandlers.print())
                .andReturn();
        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();

        Assert.assertEquals(HttpStatus.OK.value(), status);
        Assert.assertEquals("N", content);
    }

}
