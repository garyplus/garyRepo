package example.worker.demo.worker.writer;

import example.entity.worker.PocEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemWriter;

import java.util.List;

@Slf4j
public class CustNamePocWriter implements ItemWriter<PocEntity> {

	@Override
	public void write(List<? extends PocEntity> list) throws Exception {

		log.info("[write write write]");
		for(PocEntity te : list){

//			if(te.getUserName().equals("Gary Zheng8") || te.getUserName().equals("Gary Zheng9")) {
//				throw new Exception("Gary exception");
//			}

			log.info(te.getUserName());
		}
	}
}
