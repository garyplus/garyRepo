package example.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.StampedLock;

public class PessimisticLock {

    static ExecutorService service = Executors.newFixedThreadPool(10);
    static StampedLock lock = new StampedLock();
    static long milli = 1000;
    static int count = 0;

    private static long writeLock() {
        long stamp = lock.writeLock(); //获取排他写锁
        count+=1;
        lock.unlockWrite(stamp); //释放写锁
        System.out.println("数据写入完成");
        return System.currentTimeMillis();
    }
    private static void readLock() {//普通的读锁
        service.submit(() -> {
            int currentCount = 0;
            long stamp = lock.readLock(); //获取排他读锁
            try {
                try {
                    TimeUnit.MILLISECONDS.sleep(milli);//模拟读取需要花费20秒
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                currentCount = count; //获取变量值
            } finally {
                lock.unlockRead(stamp); //释放读锁
            }
            System.out.println("readLock==" + currentCount); //显示最新的变量值
        });
        try {
            TimeUnit.MILLISECONDS.sleep(500);//要等一等读锁先获得
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        long l1 = System.currentTimeMillis();
        readLock();
        long l2 = writeLock();
        System.out.println(l2-l1);
    }
}
