package example.service.impl;

import example.entity.UserBean;
import example.event.OrderEvent;
import example.event.UserRegisterEvent;
import example.mapper.TestMapper;
import example.service.AssessorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.StampedLock;

@Service
@Slf4j
public class EventServiceImpl  {

    static StampedLock lock = new StampedLock();
    static int count = 0;
    @Autowired
    private ApplicationContext context;

    public void publishUserBeanEvent() {
        UserBean ub = new UserBean();
        ub.setName("aaa");
        ub.setPassword("pppppp");
        context.publishEvent(new UserRegisterEvent(this, ub));
    }

    @Async("getAsyncExecutor")
    public void service1() throws InterruptedException {
        log.info("--------start-service1------------");
        Thread.sleep(5000); // 模拟耗时
        log.info("--------end-service1------------");
    }

    public String getServiceCount () {
        long stamp = lock.tryOptimisticRead();
        int currentCount = count;
        try {
            TimeUnit.MILLISECONDS.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (!lock.validate(stamp)) {
            stamp = lock.readLock();
            try {
                currentCount = count;
            } finally {
                lock.unlockRead(stamp);
            }
        }
        log.info("optimisticRead=={}" , currentCount);
        log.info("--------end-service3------------");
        return String.valueOf(count);
    }

    @Async("getAsyncExecutor")
    public Future<String> service2() throws InterruptedException {
        log.info("--------start-service2------------");

        long stamp = lock.writeLock();
        count+=1;
        lock.unlockWrite(stamp);
        log.info("write count to be {}" , count);
        log.info("--------end-service2------------");
        return new AsyncResult<>(String.valueOf(count));
    }

    @Async("asyncServiceExecutor")
    public Future<String> service3() throws InterruptedException {
        log.info("--------start-service3------------");

        long stamp = lock.tryOptimisticRead();
        int currentCount = count;
        try {
            TimeUnit.MILLISECONDS.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (!lock.validate(stamp)) {
            stamp = lock.readLock();
            try {
                currentCount = count;
            } finally {
                lock.unlockRead(stamp);
            }
        }
        log.info("optimisticRead=={}" , currentCount);
        log.info("--------end-service3------------");
        return new AsyncResult<>(String.valueOf(count));
    }
}
