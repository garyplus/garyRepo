package zookeeper;

import com.alibaba.csp.sentinel.slots.block.degrade.DegradeRule;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRule;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

public class GaryCreateRuleTest {
    private static final int RETRY_TIMES = 3;
    private static final int SLEEP_TIME = 1000;

    public static void main(String[] args) throws Exception {
        final String remoteAddress = "localhost:2181";
        final String rule = "[\n"
                + "  {\n"
                + "    \"resource\": \"/hi\",\n"
                + "    \"controlBehavior\": 0,\n"
                + "    \"count\": 1.0,\n"
                + "    \"grade\": 1,\n"
                + "    \"limitApp\": \"default\",\n"
                + "    \"strategy\": 0\n"
                + "  }\n"
                + "]";
        final String degradeRule = "[\n"
                + "  {\n"
                + "    \"resource\": \"/hi\",\n"
                + "    \"grade\": 1,\n"
                + "    \"count\": 1.0,\n"
                + "    \"timeWindow\": 1,\n"
                + "  }\n"
                + "]";

        CuratorFramework zkClient = CuratorFrameworkFactory.newClient(remoteAddress, new ExponentialBackoffRetry
                (SLEEP_TIME, RETRY_TIMES));
        zkClient.start();
        String appName = "Gary-testing-server";
        String path = "/sentinel_rule_config/" + appName;
        String flowPath = path +"/flow";
        String degradePath = path +"/degrade";


//        DegradeRule
        Stat stat = zkClient.checkExists().forPath(flowPath);
        if (stat == null) {
            zkClient.create().creatingParentContainersIfNeeded().withMode(CreateMode.PERSISTENT).forPath(flowPath, null);
        }
        zkClient.setData().forPath(flowPath, rule.getBytes());

//        FlowRule
        Stat stat2 = zkClient.checkExists().forPath(degradePath);
        if (stat2 == null) {
            zkClient.create().creatingParentContainersIfNeeded().withMode(CreateMode.PERSISTENT).forPath(degradePath, null);
        }
        zkClient.setData().forPath(degradePath, degradeRule.getBytes());

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        zkClient.close();
    }
}
