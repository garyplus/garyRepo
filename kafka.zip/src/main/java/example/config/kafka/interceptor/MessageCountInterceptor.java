package example.config.kafka.interceptor;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerInterceptor;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import java.text.NumberFormat;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
public class MessageCountInterceptor  implements ProducerInterceptor<String, String> {

        private AtomicInteger successCounter = new AtomicInteger();
        private AtomicInteger failCounter = new AtomicInteger();

        @Override
        public ProducerRecord<String, String> onSend(ProducerRecord<String, String> record) {
            return record;
        }

        @Override
        public void onAcknowledgement(RecordMetadata metadata, Exception exception) {
            if (exception == null) {
                successCounter.getAndIncrement();
                log.info("kafka message success counter : [{}]" , successCounter.get());
            } else {
                failCounter.getAndIncrement();
                log.info("kafka message fail counter: [{}]" , failCounter.get());
            }
            NumberFormat numberFormat = NumberFormat.getInstance();
            numberFormat.setMaximumFractionDigits(2);
            String successRate = numberFormat.format((float)successCounter.get()/(float)(failCounter.get() + successCounter.get())*100);
            log.info("send message success rate is :[{}%]" , successRate);
        }

        @Override
        public void close() {
        }

        @Override
        public void configure(Map<String, ?> configs) {
        }
    }
