package example.worker.demo.listener;

import example.entity.worker.PocEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.annotation.AfterWrite;
import org.springframework.batch.core.annotation.BeforeWrite;
import org.springframework.batch.core.annotation.OnWriteError;

import java.util.List;

@Slf4j
public class WriterListener {
    @BeforeWrite
    public void beforeWrite(List<? extends PocEntity> pocEntity) {

    }

    @AfterWrite
    public void afterWrite(List<? extends PocEntity> pocEntity) {

    }

    @OnWriteError
    public void onWriteError(Exception e,List<? extends PocEntity> pocEntity) {
    }
}
