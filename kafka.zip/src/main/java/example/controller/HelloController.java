package example.controller;

import example.entity.worker.PocEntity;
import example.service.AssessorService;
import example.service.ThreadPoolService;
import example.service.impl.KafkaServiceImpl;
import example.worker.demo.worker.processor.CustNamePocProcessor;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Duration;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Future;

@RestController
@Api(value = "desc of demo")
@Slf4j
public class HelloController {

    @Autowired
    AssessorService assessorService;

    @Autowired
    ThreadPoolService threadPoolService;

    @Autowired
    private KafkaServiceImpl kafkaServiceImpl;


    @ApiOperation(value = "desc of method", notes = "")
    @GetMapping(value = "/hi")
    public String hello(@ApiParam(value = "No. of assessor" , required = true) @RequestBody String assessorNo) {
        log.info("accept parameter:{} ", assessorNo);
        return assessorService.getAssessorInfo(assessorNo);
    }

    @ApiOperation(value = "desc of sendmsg", notes = "")
    @GetMapping(value = "/sendmsg")
    public String sendMsg(@ApiParam(value = "xmlStr" , required = true) @RequestParam String xmlStr) {
        log.info("accept parameter:{} ", xmlStr);
        kafkaServiceImpl.doSend("test",xmlStr);
        String retVar = "empty string";
        try {
            Future<String> future1 = threadPoolService.onlineConsumeKafka();
            while (true) {
                if (future1.isDone() ) {
                    retVar = future1.get();
                    log.info("Task1 result:{}", retVar);
                    break;
                }
                Thread.sleep(1000);
            }
            return retVar;
        }
        catch (InterruptedException e) {
            log.error("错误信息1", e);
            return "F";
        } catch (Exception e) {
            log.error("错误信息2", e);
            return "FX";
        }
    }

    @ApiOperation(value = "desc of sendmsg", notes = "")
    @GetMapping(value = "/pub")
    public String pub(@ApiParam(value = "msg" , required = true) @RequestParam String msg) {
        kafkaServiceImpl.doSend("test2",msg);
        return "publish message to topic2";
    }



    @ApiOperation(value = "desc of sendmsg", notes = "")
    @GetMapping(value = "/sub")
    public String sub() throws InterruptedException {

        String retVar = "";
        String topicName = "test2";
        int offSet = 0;
        int partition = 0;
        int count = 1;
        boolean retFlag = false;
        boolean hasMsg = false;
        while (!retFlag) {
        //load kafka config
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("group.id", "test");
        props.put("enable.auto.commit", false);
        props.put("auto.commit.offset", false);
//        props.put("auto.commit.interval.ms", "1000");
        props.put("session.timeout.ms", "15000");
        props.put("max.poll.records", 1);
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        //create consumer
        log.info("offSet = {}", offSet);
        KafkaConsumer consumer = new KafkaConsumer<String, String>(props);
        if(!hasMsg){
            if(offSet == 0) {
                consumer.subscribe(Arrays.asList("test2"));
            }
        }else{
            log.info("come to read target offset , offSet = {} ", offSet);
            consumer.assign(Arrays.asList(new TopicPartition(topicName, partition)));
            consumer.seek(new TopicPartition(topicName, partition), offSet);
        }
            log.info("=======================================separate line=====================================");
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(300));
            if(records.count() != 0){
                hasMsg =true;
            }else{
                hasMsg = false;
            }
            for (ConsumerRecord<String, String> record : records) {
                log.info("topic = {}, partition = {}, offset = {}, " + "key = {}, value = {}",
                        record.topic(), record.partition(), record.offset(), record.key(), record.value());
                if(record.value().equals("b")){
                    consumer.commitAsync(new OffsetCommitCallback() {
                        @Override
                        public void onComplete(Map<TopicPartition, OffsetAndMetadata> offsets, Exception exception) {
                            if (exception != null) {
                                System.out.println("提交失败：" + offsets);
                            }
                        }
                    });
                }else{
                    offSet = (int) (record.offset() + 1);
                    partition = (int) (record.partition() + 1);
                    log.info("update offSet = {}", offSet);
                }
            }
            count++;
            Thread.sleep(10000);
            consumer.close();
        }

        return "publish message to topic2";
    }


    @ApiOperation(value = "desc of sendmsg", notes = "")
    @GetMapping(value = "/test")
    public String test() {
        kafkaServiceImpl.doSend("test2","topic 2 message through api");
        return "already send message to topic 2";
    }

    @GetMapping("/thread")
    public String testThread() {
        try {
            Future<String> future1 = threadPoolService.doTask1();
            Future<String> future2 = threadPoolService.doTask2();

        while (true) {
            if (future1.isDone() && future2.isDone()) {
                log.info("Task1 result:{}", future1.get());
                log.info("Task2 result:{}", future2.get());
                break;
            }
            Thread.sleep(1000);
        }
        log.info("All tasks finished.");
        return "S";
        } catch (InterruptedException e) {
        log.error("错误信息1", e);
        return "F";
        } catch (Exception e) {
        log.error("错误信息2", e);
        return "FX";
        }
    }

}
