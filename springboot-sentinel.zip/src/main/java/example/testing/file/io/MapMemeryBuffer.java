package example.testing.file.io;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class MapMemeryBuffer {

    public static void main(String[] args) throws Exception {
        Runtime run = Runtime.getRuntime();

        long max = run.maxMemory() /1024 /1024;

        long total = run.totalMemory() /1024 /1024;

        long free = run.freeMemory() /1024 /1024;

        long usable = max - total + free;

        System.out.println("before start...");
        System.out.println("最大内存 = " + max);
        System.out.println("已分配内存 = " + total);
        System.out.println("已分配内存中的剩余空间 = " + free);
        System.out.println("最大可用内存 = " + usable);

        ByteBuffer byteBuf = ByteBuffer.allocate(1024 * 14 * 1024);
        byte[] bbb = new byte[14 * 1024 * 1024];
        FileInputStream fis = new FileInputStream("C://Users/ASNPI4V/improve/workspace/Sentinel/springboot-sentinel/startup006/src/main/java/example/testing/file/io/inFile.txt");
        FileOutputStream fos = new FileOutputStream("C://Users/ASNPI4V/improve/workspace/Sentinel/springboot-sentinel/startup006/src/main/java/example/testing/file/io//outFile.txt");
        FileChannel fc = fis.getChannel();
        long timeStar = System.currentTimeMillis();
//        fc.read(byteBuf);
        MappedByteBuffer mbb = fc.map(FileChannel.MapMode.READ_WRITE, 0, fc.size());
        System.out.println("before write..." +fc.size());
        System.out.println(fc.size()/1024);
        long timeEnd = System.currentTimeMillis();
        System.out.println("Read time :" + (timeEnd - timeStar) + "ms");
        timeStar = System.currentTimeMillis();
//        fos.write(bbb)；


        max = run.maxMemory() /1024 /1024;

        total = run.totalMemory() /1024 /1024;

        free = run.freeMemory() /1024 /1024;

        usable = max - total + free;
        System.out.println("before write...");
        System.out.println("最大内存 = " + max);
        System.out.println("已分配内存 = " + total);
        System.out.println("已分配内存中的剩余空间 = " + free);
        System.out.println("最大可用内存 = " + usable);
            MappedByteBuffer [] arr =  new MappedByteBuffer []{mbb,mbb};
            fos.getChannel().write(arr);
        System.out.println("after...");
        max = run.maxMemory() /1024 /1024;

        total = run.totalMemory() /1024 /1024;

        free = run.freeMemory() /1024 /1024;

        usable = max - total + free;
        System.out.println("最大内存 = " + max);
        System.out.println("已分配内存 = " + total);
        System.out.println("已分配内存中的剩余空间 = " + free);
        System.out.println("最大可用内存 = " + usable);
        timeEnd = System.currentTimeMillis();
        System.out.println("Write time :" + (timeEnd - timeStar) + "ms");
        fos.flush();
        fc.close();
        fis.close();
    }

}
