package example.service.impl;

import example.mapper.PocMapper;
import example.service.AssessorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AssessorServiceImpl implements AssessorService {

    @Autowired
    private PocMapper testMapper;

    @Override
    public String getAssessorInfo(String assessorNo) {

        return testMapper.getAssessorInfo(assessorNo);
    }
}
