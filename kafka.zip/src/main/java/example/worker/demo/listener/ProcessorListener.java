package example.worker.demo.listener;

import example.entity.worker.PocEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.annotation.AfterProcess;
import org.springframework.batch.core.annotation.BeforeProcess;
import org.springframework.batch.core.annotation.OnProcessError;

@Slf4j
public class ProcessorListener {
    @BeforeProcess
    public void beforeProcess(PocEntity pocEntity) {

    }

    @AfterProcess
    public void afterProcess(PocEntity ip_pocEntity,PocEntity out_pocEntity) {

    }

    @OnProcessError
    public void onProcessError(PocEntity pocEntity,Exception e) {

    }
}
