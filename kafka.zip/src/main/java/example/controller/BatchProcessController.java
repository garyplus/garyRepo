package example.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.scope.context.StepSynchronizationManager;
import org.springframework.batch.core.step.NoSuchStepException;
import org.springframework.batch.core.step.StepLocator;
import org.springframework.batch.core.step.tasklet.StoppableTasklet;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.core.step.tasklet.TaskletStep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Iterator;
import java.util.Set;


@RestController
@Api(value = "desc of demo")
@Slf4j
public class BatchProcessController {

    @Autowired
    JobLauncher jobLauncher;


    @Autowired
    JobOperator jobOperator;

    @Autowired
    JobRegistry jobRegistry;



    @GetMapping("/runJob")
    public Long runJob(HttpServletRequest request,@RequestParam String jobName) throws Exception {
        ApplicationContext ac = WebApplicationContextUtils.getRequiredWebApplicationContext(request.getServletContext());
        ConfigurableApplicationContext context = (ConfigurableApplicationContext) ac;
        DefaultListableBeanFactory dbf = (DefaultListableBeanFactory) context.getBeanFactory();
        Job job = (Job)dbf.getBean(jobName);

        JobParameters jobParameters = new JobParametersBuilder().addLong("time",System.currentTimeMillis()).toJobParameters();
        //JobExecution run = jobLauncher.run(job, new JobParametersBuilder().addLong("time",System.currentTimeMillis()).toJobParameters());
        JobExecution run = jobLauncher.run(job, jobParameters);
        return run.getId();
    }

// only support Tasklet, cannot support chunk , supplement it later
    @GetMapping("/stopJob")
    public void stopJob(@RequestParam String jobName) throws Exception {
        Set<Long> executions = jobOperator.getRunningExecutions(jobName);
        log.info("job name is :{}", jobName);
        jobOperator.stop(executions.iterator().next());

    }
}
