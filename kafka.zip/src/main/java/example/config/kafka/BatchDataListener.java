package example.config.kafka;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import java.util.List;


@Component
@Slf4j
public class BatchDataListener {

    @KafkaListener(topics = {"${kafka.consumer.topic}"}, containerFactory="kafkaBatchFactory")
    public void consumerBatch( List<ConsumerRecord<?, ?>> records, Acknowledgment ack){
        log.info("recv message count is ：{}",records.size());
        for(ConsumerRecord record : records){

            String value = (String) record.value();
            String topic = record.topic();
            log.info("recv message topic is ：{}", topic);
            log.info("recv message content is ：{}", value);
            if(value.equals("Gary Zheng1")){
                ack.acknowledge();
            }
            else{
//                ack.nack(1000);
            }
        }
    }
}
