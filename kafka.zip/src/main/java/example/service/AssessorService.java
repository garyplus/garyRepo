package example.service;

public interface AssessorService {
    String getAssessorInfo(String assessorNo);
}
