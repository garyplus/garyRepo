import React, { Component } from "react";
import "./index.css";
import { Link } from 'react-router-dom';



class Logon extends Component {

  constructor() {
    super();

    this.state = {
      
    };

  }
  render() {
    return (
      <div>
        <header className="mdc-toolbar mdc-toolbar--fixed">
          <div className="mdc-toolbar__row">
            <section className="mdc-toolbar__section mdc-toolbar__section--align-start">
              <span className="mdc-toolbar__title">SME POTAL POC</span>
            </section>
          </div>
        </header>
        <div className="toolbar-adjusted-content">
        <section id="login">
            <div>
                <span>
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAABGdBTUEAALGPC/xhBQAAACBjSFJN
AAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAAsVBMVEX///9lZ2ZlZ2ZlZ2Zl
Z2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2Zl
Z2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2Zl
Z2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2b///9zjW6+AAAA
OXRSTlMACXLQ+fvYgRAe1OMv5WQaFlfnHA/SkkTtAwL4GfYbN/MFBsGh8iEpjf7pKLJm/LFgKoK4
JX0Bw+8GY9SiAAAAAWJLR0QAiAUdSAAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB+MDCgcn
Ey8tvAYAAADmSURBVCjPdY/peoIwEEXjhlTFrSqtqbV1KbUgiyx63v/FCiJK4PP+mck9mdyJEDc1
mq12R+vqoqKXHlf1B6rf6GEMR+OJxnSsgCbGa1ZncxYKaDHMG5O39zJoM8qbpeSjDDoUT6/4LAON
Sd6s+fougy7aLKubLTslXO8zN5divWX/o35kMAW5gr1Z+bn1axzg8LewFNt2uMuxH/5R4np+oOuB
77nIY+GfIIyKQxTC6XYf4uQxnsRwnbElsbpIjMxyHMJEBUmIk+6JG4mKIhcrTfZETV6af8avA5+z
uBDUQcBF8ERPwT/mXyiV5dBWigAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxOS0wMy0wOVQyMzozOTox
OSswODowMA/qHXIAAAAldEVYdGRhdGU6bW9kaWZ5ADIwMTktMDMtMDlUMjM6Mzk6MTkrMDg6MDB+
t6XOAAAAAElFTkSuQmCC" width="24" height="24" />
                </span>
                <input type="text" id="txtuser" name="txtuser" placeholder="Please input your user name"/>
            </div>
            <div>
              <span>
                  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAABGdBTUEAALGPC/xhBQAAACBjSFJN
AAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAASFBMVEX///9lZ2ZlZ2ZlZ2Zl
Z2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2ZlZ2b/
//9jtC3aAAAAFnRSTlMAIZfh/WH4WLpDFPOOAYDKA873HAUQO1Jq0QAAAAFiS0dEAIgFHUgAAAAJ
cEhZcwAACxMAAAsTAQCanBgAAAAHdElNRQfjAwoHKRLGqaEeAAAAaUlEQVQoz+WQyQ6AIBDFEBcU
d8D+/6ca95GYGM/21LwmcxildhKdZlmqExWRF6wU+X03UFbWViUYuduapl2kbaitCB39sNnQ04kw
XgcMowgOf6jHiQDh0AC38OQ88BamiDPE//lP+PTEGQYgD/uK9l3SAAAAJXRFWHRkYXRlOmNyZWF0
ZQAyMDE5LTAzLTA5VDIzOjQxOjE4KzA4OjAwk3FDsQAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxOS0w
My0wOVQyMzo0MToxOCswODowMOIs+w0AAAAASUVORK5CYII=" width="24" height="24"/>
              </span>
              <input id="txtpwd" name="txtpwd" type="password" placeholder="please input your password"/>
            </div>
            
            <Link to="/dashboard" className="btnLogin">Login</Link>
            <a href="#" className="btnRegister">Register</a>
        </section>
 
      </div>
      </div>
    );
  }
}

export default Logon;
