import React from "react";
import ReactDOM from "react-dom";

import MainPage from "./components/index/index";
import Logon from "./components/logon/index";
import Dashboard from "./components/dashboard/index";
import App from "./App";
import "./index.css";

import registerServiceWorker from "./registerServiceWorker";
import "material-icons/css/material-icons.css";
import {
    HashRouter,
    Route
  } from 'react-router-dom';


//ReactDOM.render(<App />, document.getElementById("root"));

ReactDOM.render(<HashRouter>
    <MainPage>
        <Route path="/logon" component={Logon} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/widget" component={App} />
    </MainPage>
  </HashRouter>,
    document.getElementById('root'));
registerServiceWorker();
