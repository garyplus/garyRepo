package example.service.impl;

import example.mapper.TestMapper;
import example.service.AssessorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AssessorServiceImpl implements AssessorService {

    @Autowired
    private TestMapper testMapper;

    @Override
    public String getAssessorInfo(String assessorNo) {

        return testMapper.getAssessorInfo(assessorNo);
    }
}
