package example.config;

import com.alibaba.csp.sentinel.datasource.FileRefreshableDataSource;
import com.alibaba.csp.sentinel.datasource.ReadableDataSource;
import com.alibaba.csp.sentinel.datasource.zookeeper.ZookeeperDataSource;
import com.alibaba.csp.sentinel.slots.block.degrade.DegradeRule;
import com.alibaba.csp.sentinel.slots.block.degrade.DegradeRuleManager;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRule;
import com.alibaba.csp.sentinel.slots.block.flow.FlowRuleManager;
import com.alibaba.csp.sentinel.slots.block.flow.param.ParamFlowRule;
import com.alibaba.csp.sentinel.slots.block.flow.param.ParamFlowRuleManager;
import com.alibaba.csp.sentinel.slots.system.SystemRule;
import com.alibaba.csp.sentinel.slots.system.SystemRuleManager;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import javax.annotation.PostConstruct;
import java.io.File;
import java.util.List;

@Slf4j
@Component
public class ZookeeperSentinelConfig {
//    @Value("${spring.application.name}")
//    private String appName;
//
//    @Value("${zookeeper.servers}")
//    private String zookeeperServer;


    @PostConstruct
    public void loadRules() {
        //load from local file
//        try {
//            File file = ResourceUtils.getFile("classpath:sentinel/flow-rule.json");
//            ReadableDataSource<String, List<FlowRule>> flowRuleDataSourceLocal = new FileRefreshableDataSource<>(file,
//                    source -> JSON.parseObject(
//                            source,
//                            new TypeReference<List<FlowRule>>() {
//                            }
//                    ));
//            FlowRuleManager.register2Property(flowRuleDataSourceLocal.getProperty());
//        } catch (Exception e) {
//            log.error("init localRules failed");
//            log.error(e.getMessage(), e);
//        }

//        final String remoteAddress = zookeeperServer;
//        final String flowPath = "/sentinel_rule_config/" + appName + "/flow";
//        final String degradePath = "/sentinel_rule_config/" + appName + "/degrade";
//        final String paramFlowPath  = "/sentinel_rule_config/" + appName + "/paramFlow";
//        final String systemPath = "/sentinel_rule_config/" + appName + "/system";
//
//        // load flow rule from zookeeper
//        ReadableDataSource<String, List<FlowRule>> flowRuleDataSource = new ZookeeperDataSource<>(remoteAddress, flowPath,
//                source -> JSON.parseObject(source, new TypeReference<List<FlowRule>>() {
//                }));
//
//        FlowRuleManager.register2Property(flowRuleDataSource.getProperty());
//
//        // load degrade rule from zookeeper
//        ReadableDataSource<String, List<DegradeRule>> redisDegradeDataSource = new ZookeeperDataSource<>(remoteAddress, degradePath,
//                source -> JSON.parseObject(source, new TypeReference<List<DegradeRule>>() {
//                }));
//        DegradeRuleManager.register2Property(redisDegradeDataSource.getProperty());
//
//        // load paramFlow rule from zookeeper
//        ReadableDataSource<String, List<ParamFlowRule>> paramFlowDataSource = new ZookeeperDataSource<>(remoteAddress, paramFlowPath,
//                source -> JSON.parseObject(source, new TypeReference<List<ParamFlowRule>>() {
//                }));
//        ParamFlowRuleManager.register2Property(paramFlowDataSource.getProperty());
//
//        // load system rule from zookeeper
//        ReadableDataSource<String, List<SystemRule>> systemRuleDataSource = new ZookeeperDataSource<>(remoteAddress, systemPath,
//                source -> JSON.parseObject(source, new TypeReference<List<SystemRule>>() {}));
//        SystemRuleManager.register2Property(systemRuleDataSource.getProperty());
    }
}