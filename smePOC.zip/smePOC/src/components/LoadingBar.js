import React, { Component } from "react";

class LoadingBar extends Component {
  render() {
    return (
      <div className="center">
        
      </div>
    );
  }
}

export default LoadingBar;
