package example.entity;

import lombok.Data;

@Data
public class UserBean {
    //用户名
    private String name;
    //密码
    private String password;
}