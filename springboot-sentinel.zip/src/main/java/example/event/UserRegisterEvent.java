package example.event;


import example.entity.UserBean;
import org.springframework.context.ApplicationEvent;

public class UserRegisterEvent extends ApplicationEvent {

    private UserBean user;

    public UserRegisterEvent(Object source, UserBean user) {
        super(source);
        this.user = user;
    }

    public UserBean getUser() {
        return this.user;
    }
}