package example.config;

import example.controller.HelloController;
import example.entity.UserBean;
import example.event.OrderEvent;
import example.event.UserRegisterEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.event.SmartApplicationListener;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class UserBeanListener implements SmartApplicationListener {

    @Override
    public boolean supportsEventType(Class<? extends ApplicationEvent> aClass) {
        //only process the event base on UserRegisterEvent entity
        return aClass == UserRegisterEvent.class;
    }


    @Override
    public boolean supportsSourceType(Class<?> aClass) {
        //it will handle the request under source class is HelloController
        log.info("source class is {}", aClass);
        log.info("return flag is {}", aClass == HelloController.class);
        return aClass == HelloController.class;
    }


    @Override
    public void onApplicationEvent(ApplicationEvent applicationEvent) {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        UserRegisterEvent userRegisterEvent = (UserRegisterEvent) applicationEvent;
        UserBean user = userRegisterEvent.getUser();
        log.info("user name is {} , user password is {}", user.getName(), user.getPassword());
    }

    /**
     * process priority for the event , lower means higher priority
     * @return
     */
    @Override
    public int getOrder() {
        return 1;
    }
}