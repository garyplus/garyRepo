package example.worker.demo.worker.reader;

import example.entity.worker.PocEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

@Slf4j
public class CustomNamePocReader implements ItemReader<PocEntity> {
	private volatile int count = 1;

	@Override
	public PocEntity read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		if (count<=11){
			log.info("............read read read............");
			PocEntity te = new PocEntity();
			te.setUserName("Gary Zheng"+ count);
			count++;
			return te;
		}
		else{
			return null;
		}
	}

}
