package example.config;

import example.worker.demo.worker.quartz.QuartzJobLauncher;
import org.springframework.batch.core.configuration.JobLocator;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.support.JobRegistryBeanPostProcessor;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class QuartzJobConfiguration {

	@Autowired
	private JobLauncher jobLauncher;

	@Autowired
	private JobLocator jobLocator;

	@Bean
	public JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor(JobRegistry jobRegistry) {
		JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor = new JobRegistryBeanPostProcessor();
		jobRegistryBeanPostProcessor.setJobRegistry(jobRegistry);
		return jobRegistryBeanPostProcessor;
	}

	@Bean
	public JobDetailFactoryBean jobDetailFactoryBean() {
		JobDetailFactoryBean jobDetailFactoryBean = new JobDetailFactoryBean();
		jobDetailFactoryBean.setJobClass(QuartzJobLauncher.class);

		Map<String, Object> jobDataMap = new HashMap<>();
		jobDataMap.put("jobName", "garyPocJob");
		jobDataMap.put("jobLauncher", jobLauncher);
		jobDataMap.put("jobLocator", jobLocator);

		jobDetailFactoryBean.setJobDataAsMap(jobDataMap);
		return jobDetailFactoryBean;
	}

	@Bean
	public CronTriggerFactoryBean tenSecondsIntervalCronBean(){
		CronTriggerFactoryBean cronTriggerFactoryBean = new CronTriggerFactoryBean();
		cronTriggerFactoryBean.setJobDetail(jobDetailFactoryBean().getObject());
		cronTriggerFactoryBean.setCronExpression("*/10 * * 1 * ? * ");
		return cronTriggerFactoryBean;
	}

	@Bean
	public JobDetailFactoryBean threeSecondJob() {
		JobDetailFactoryBean jobDetailFactoryBean = new JobDetailFactoryBean();
		jobDetailFactoryBean.setJobClass(QuartzJobLauncher.class);

		Map<String, Object> jobDataMap = new HashMap<>();
		jobDataMap.put("jobName", "garyPocTaskletJob");
		jobDataMap.put("jobLauncher", jobLauncher);
		jobDataMap.put("jobLocator", jobLocator);

		jobDetailFactoryBean.setJobDataAsMap(jobDataMap);
		return jobDetailFactoryBean;
	}

	@Bean
	public CronTriggerFactoryBean threeSecondsIntervalCronBean(){
		CronTriggerFactoryBean cronTriggerFactoryBean = new CronTriggerFactoryBean();
		cronTriggerFactoryBean.setJobDetail(threeSecondJob().getObject());
		cronTriggerFactoryBean.setCronExpression("*/20 * * 1 * ? * ");
		return cronTriggerFactoryBean;
	}
	
	@Bean
	public SchedulerFactoryBean schedulerFactoryBean(){
		SchedulerFactoryBean schedulerFactoryBean = new SchedulerFactoryBean();
		schedulerFactoryBean.setTriggers(
				tenSecondsIntervalCronBean().getObject()
//				,threeSecondsIntervalCronBean().getObject()
				);
		return schedulerFactoryBean;
	}
}
