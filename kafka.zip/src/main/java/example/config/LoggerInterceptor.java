package example.config;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.MDC;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Enumeration;
import java.util.UUID;

@Aspect
@Configuration
@Slf4j
public class LoggerInterceptor {
    @Pointcut("execution(* example.controller.*.*(..))")
    public void executionService() {}

    /**
     * @param joinPoint
     */
    @Before(value = "executionService()")
    public void doBefore(JoinPoint joinPoint){
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
        HttpServletRequest request = sra.getRequest();

        HttpSession session = request.getSession(false);

        Enumeration<String> enumeration = request.getHeaderNames();
        StringBuffer headers = new StringBuffer();
        while (enumeration.hasMoreElements()) {
            String name = enumeration.nextElement();
            String value = request.getHeader(name);
            headers.append(name + ":" + value).append(",");
        }
        String uri = request.getRequestURI();
        String url = request.getRequestURL().toString();
        String method = request.getMethod();
        String queryString = request.getQueryString();

        String requestId = request.getHeader("x-request-id");
        log.info("x-request id from caller is {}", requestId);
        log.info("request start, args, url: {}, method: {}, uri: {}, params: {}, headers: {}", url, method, uri, queryString, headers);

        requestId = null != requestId ? requestId : String.valueOf(UUID.randomUUID());
        MDC.put("requestId", requestId);
    }

//    @Around(value = "executionService()")
//    public Object doAround(ProceedingJoinPoint pjp) throws Throwable {
//        HttpRequest httpRequest = ResteasyProviderFactory.getContextData(HttpRequest.class);
//        HttpHeaders httpHeaders = httpRequest.getHttpHeaders();
//        String headerString = httpHeaders.getHeaderString("request-id");
//
//        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
//        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
//        HttpServletRequest request = sra.getRequest();
//
//        String url = request.getRequestURL().toString();
//        String method = request.getMethod();
//        String uri = request.getRequestURI();
//        String queryString = request.getQueryString();
//        log.info("request start, args, url: {}, method: {}, uri: {}, params: {}", url, method, uri, queryString);
//
//        Object result = pjp.proceed();
//        log.info("return body is: [{}]", result);
//        return result;
//    }
    /**
     * @param joinPoint
     * @param returnValue
     */
    @AfterReturning(pointcut = "executionService()", returning = "returnValue")
    public void  doAfterReturning(JoinPoint joinPoint, Object returnValue){
        log.info("=====>return body is: [{}]", returnValue);
        MDC.clear();
    }
}
