package example.service.impl;

import example.service.ThreadPoolService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Future;

@Slf4j
@Service
public class ThreadPoolServiceImpl implements ThreadPoolService {

    @Override
    @Async("onlineAsyncServiceExecutor")
    public Future<String> doTask1() throws InterruptedException{
        log.info("Task1 started.");
        long start = System.currentTimeMillis();
        Thread.sleep(5000);
        long end = System.currentTimeMillis();

        log.info("Task1 finished, time elapsed: {} ms.", end - start);

        return new AsyncResult<>("Task1 accomplished!");
    }


    @Override
    @Async("onlineAsyncServiceExecutor")
    public Future<String> onlineConsumeKafka() throws InterruptedException{
        log.info("OnlineConsumeKafka started.");
        long start = System.currentTimeMillis();


        //load kafka config
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("group.id", "test");
        props.put("enable.auto.commit", "false");
//        props.put("auto.commit.interval.ms", "1000");
        props.put("session.timeout.ms", "15000");
        props.put("max.poll.records", "1");
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
         //create consumer
        KafkaConsumer consumer = new KafkaConsumer<String,String>(props);
        consumer.subscribe(Arrays.asList("test2"));
        String retVar = "";
        int count = 1;
        boolean retFlag = false;
        while (count <= 30&&!retFlag){
           log.info("=======================================separate line=====================================");
            ConsumerRecords<String, String> records = consumer.poll(100);
            for (ConsumerRecord<String, String> record : records) {
                log.info("count is :{} ,record.value();......"+record.value(), count);
                consumer.commitAsync(new OffsetCommitCallback() {
                    @Override
                    public void onComplete(Map<TopicPartition, OffsetAndMetadata> offsets, Exception exception) {
                        if (exception != null) {
                            System.out.println("提交失败：" + offsets);
                        }
                    }
                }); // ack message
                retVar = record.value();

            }
            count++;
            if(!StringUtils.isBlank(retVar)){
                retFlag = true;
                continue;
            }
            Thread.sleep(3000);
        }
        consumer.close();
        long end = System.currentTimeMillis();

        log.info("Task1 finished, time elapsed: {} ms.", end - start);

        if(StringUtils.isBlank(retVar)){
            retVar = "no response or timeout for this process";
        }
        return new AsyncResult<>(retVar);
    }


    @Override
    @Async("onlineCustomServiceExecutor")
    public Future<String> doTask2() throws InterruptedException{
        log.info("Task2 started.");
        long start = System.currentTimeMillis();
        Thread.sleep(3000);
        long end = System.currentTimeMillis();

        log.info("Task2 finished, time elapsed: {} ms.", end - start);

        return new AsyncResult<>("Task2 accomplished!");
    }
}
